SELECT 'Today''s date is ' + CONVERT(varchar(12), GETDATE(),101)

