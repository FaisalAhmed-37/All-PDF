SELECT * FROM Person.Address;

