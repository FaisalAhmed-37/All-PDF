USE AdventureWorks;

SELECT * FROM CustomerNotes;

EXEC sp_help CustomerNotes;

