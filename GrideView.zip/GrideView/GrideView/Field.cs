﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrideView
{
   public class Field
    {
       public string id { get; set; }
       public string Name { get; set; }
       public string Number { get; set; }
       public string Comment { get; set; }


    }
}
