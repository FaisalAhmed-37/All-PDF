﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GrideView
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        public List<Field> result = new List<Field>();
        private void btnInsert_Click(object sender, EventArgs e)
        {
            result.Add(new Field { id = txtID.Text, Name = txtName.Text, Number = txtNumber.Text, Comment = txtFail.Text});
            ShowData();
            clr();
            
        }

        public void ShowData()
        {
            ShowAndEditData.DataSource = result.ToList();
        }


        public void clr()
        {
            txtID.Clear();
            txtName.Clear();
            txtNumber.Clear();
            txtFail.Clear();
            txtID.Focus();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {

            Field find = result.Find(f => f.id == txtID.Text);
            result.Remove(find);
            ShowData();
            clr();
        }

        private void ShowAndEditData_CellDoubleClick(object sender, MouseEventArgs e)
        {
            txtID.Text = ShowAndEditData.SelectedRows[0].Cells[0].Value.ToString();
            txtName.Text = ShowAndEditData.SelectedRows[0].Cells[1].Value.ToString();
            txtNumber.Text = ShowAndEditData.SelectedRows[0].Cells[2].Value.ToString();
            txtFail.Text = ShowAndEditData.SelectedRows[0].Cells[3].Value.ToString();
            txtID.ReadOnly = true;


        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Field find = result.Find(f => f.id == txtID.Text);
            result.Remove(find);
            result.Add(new Field { id = txtID.Text, Name = txtName.Text, Number = txtNumber.Text, Comment = txtFail.Text });
            ShowData();
            clr();
            txtID.ReadOnly = true;
        }
    }
}
