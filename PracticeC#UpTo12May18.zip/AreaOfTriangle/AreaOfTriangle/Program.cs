﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaOfTriangle
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("type tbh to find the area of triangle through heron's formula");
            string typedvalue = Console.ReadLine();
            if (typedvalue == "tbh")
            {
                Console.WriteLine("Type the value of first side");
                string side1 = Console.ReadLine();
                Console.WriteLine("Type the value of second side");
                string side2 = Console.ReadLine();
                Console.WriteLine("type the value of third side");
                string side3 = Console.ReadLine();
                double fside = double.Parse(side1);
                double sside = double.Parse(side2);
                double thside = double.Parse(side3);
                double s = (fside + sside + thside) / 2.0;
                double har = Math.Sqrt(s * (s - fside) * (s - sside) * (s - thside));
                Console.ReadLine();
            }
        }
    }
}
