﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace HelloWorld
{
    class Program
    {
        public class HelloWorld
        {
            public static void Main()
            {
               // Console.WriteLine("Hellow World");



                //Console.WriteLine("Hello World!");             // relies on "using System;"
                Console.Write("This is...");
                Console.Write(" my first program!\n");
                Console.WriteLine("Welcome To C# World!");//fhdjfhdfmldfkjdkjfdj
               // System.Console.WriteLine("Goodbye World!");    // no "using" statement required
                Console.Read();
            }
        }
    }
}
