﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OddEvenFind
{
    class Program

    {

        static void Main(string[] args)

        {

            int i=0;

            Console.Write("Enter a Number : ");

            i = int.Parse(Console.ReadLine());

            if (i % 2 == 0)

            {

                Console.Write("Entered Number is an Even Number");

                Console.Read();

            }

            else

            {

                Console.Write("Entered Number is an Odd Number");

                Console.Read();

            }

        }

    }
}
