
use ProjectDatabase;
go
create proc SP_InsertProjectDetails
									@PID as int,
									@ProjectManagerID as int,
									@EmployeeID as int,
									@DepartmentID as int,
									@HourlyRate as money
as
	begin
		begin try
			Insert into ProjectDetails(PID, ProjectManagerID, EmployeeID, DepartmentID, HourlyRate)
									   values (@PID,@ProjectManagerID,@EmployeeID,@DepartmentID,@HourlyRate);
		end try
		begin catch
			Select ERROR_MESSAGE() as ErrorMessage,
				   ERROR_SEVERITY() as Severity,
				   ERROR_LINE() as [LineNo];
		end catch
	end
go
create Function FN_GetBudget(@ProjectID as int)
returns money
as
begin
	declare @BudgetMoney  money;
	select @BudgetMoney = BudgetMoney from ProjectHeader as ph 
			where ph.PID = @ProjectID ;
	return @BudgetMoney;
end
go
create Function FN_EmployeeSalaryDetail(@EmployeeID as int)
returns table
as
	return
	select ph.PTitle, e.EName, ph.BudgetMoney,  d.DName
		   from projectHeader as ph
		   inner join ProjectDetails as pd
		   on ph.PID = pd.PID
		   inner join Department as d
		   on d.DID = pd.DepartmentID
		   inner join Employee as e
		   on e.EID = pd.EmployeeID
		   where e.EID = @EmployeeID;

go 




