
create database ProjectDatabase
on primary
(
Name = 'ProjectData',
FileName = 'C:\Program Files\Microsoft SQL Server\MSSQL11.IDBDB\MSSQL\DATA\ProjectDataFile.mdf',
Size = 1gb,
Maxsize = 2gb,
filegrowth = 5mb
)
log on 
(
Name = 'ProjectLog',
FileName = 'C:\Program Files\Microsoft SQL Server\MSSQL11.IDBDB\MSSQL\DATA\ProjectLogFile.ldf',
Size = 500mb,
Maxsize = 1gb,
filegrowth = 5mb
);
go
use ProjectDatabase;
go
--1
create table Employee
(
EID int identity(100,1)  not null,
EName varchar(50) not null,
EPhone char(11) not null 
);
go
--2
create table Department
(
DID int identity (1,1)  not null,
DName varchar(30) not null
);
go
--3
create table ProjectHeader
(
PID int identity (1,1) not null,
PTitle varchar(30) not null,
BudgetMoney money not null
);
go
--4
Create table ProjectDetails
(
PID int Constraint FK_ProjectHeader_PID Foreign key references ProjectHeader(PID) not null,
ProjectDetailID int identity primary key not null,
ProjectManagerID int Constraint FK_Employee_EID_ProjectManagerID Foreign key references Employee(EID) not null,
EmployeeID int  Constraint FK_Employee_EID Foreign key references Employee(EID) not null,
DepartmentID int Constraint FK_DepartMent_DID Foreign key references Department(DID) not null,
HourlyRate money not null
);
go
create unique clustered index IX_Employee_EID
on Employee(EID);
create unique clustered index IX_Department_DID
on Department(DID);
create unique clustered index IX_ProjectHeader_PID
on ProjectHeader(PID);
create unique nonclustered index IX_Employee_EPhone
on Employee(EPhone);
go

