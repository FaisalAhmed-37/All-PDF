

use ProjectDatabase;
go
insert into Employee values('Hasan', '01922166098'),
						   ('Faisal','01926568440'),
						   ('Saddam','01926565540'),
						   ('Manik','01926556340'),
						   ('Abdul Jabbar','01926885540'),
						   ('Tareque','01866565540'),
						   ('Abdul Malek','01726565540'),
						   ('Hasina','01766565540');
go
Insert Into Department values ('IT'),
							  ('Database'),
							  ('Business Process');

Insert Into ProjectHeader values ('HR', 9800000.00),
								 ('Payroll', 8700000.00);


go

Insert Into ProjectDetails(PID, ProjectManagerID, EmployeeID, DepartmentID, HourlyRate)
						   values(1,100,102,1,600),
								 (1,100,103,1,570),
								 (2,101,104,2,570),
								 (2,101,105,1,500),
								 (2,101,106,3,730);
 
						   





